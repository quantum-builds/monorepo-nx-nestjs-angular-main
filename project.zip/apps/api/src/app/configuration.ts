export default () => ({
  MONGO_URI:"mongodb+srv://user1:ahYJwftSP0CuMK7r@cluster0.vksow.mongodb.net/myDatabase?retryWrites=true&w=majority",
  SECRET_KEY:"s234%&/^%+dfaasdfasfas435345oı3asf^+^+dfgdfe453454353+ESFASdfa"
});
