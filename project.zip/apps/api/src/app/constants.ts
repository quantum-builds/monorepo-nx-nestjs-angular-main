// This is where you define the JWT secret and other related constants
export const jwtConstants = {
    secret: 'secret', // Replace with your actual secret key
  };
  